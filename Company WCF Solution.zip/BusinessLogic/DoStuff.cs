﻿using Company.WCF.Application.DataContracts;

namespace $safeprojectname$
{
    public class DoStuff : IDoStuff
    {
        public DataResponse HandleRequest(DataRequest request)
        {
            DataResponse response = new DataResponse();
            response.Text = string.Format("Hello {0}!", request.Name);
            return response;
        }
    }
}

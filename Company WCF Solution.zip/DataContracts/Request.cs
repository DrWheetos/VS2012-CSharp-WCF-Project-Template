﻿using System.Runtime.Serialization;

namespace $safeprojectname$
{
    [DataContract]
    public class DataRequest
    {
        [DataMember]
        public string Name { get; set; }
    }
}

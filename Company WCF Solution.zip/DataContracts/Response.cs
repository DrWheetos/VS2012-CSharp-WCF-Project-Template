﻿using System.Runtime.Serialization;

namespace $safeprojectname$
{
    [DataContract]
    public class DataResponse
    {
        [DataMember]
        public string Text { get; set; }
    }
}

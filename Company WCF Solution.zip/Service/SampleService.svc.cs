﻿using Company.WCF.Application.BusinessLogic;
using Company.WCF.Application.DataContracts;
using Company.WCF.Application.ServiceContracts;

namespace $safeprojectname$
{
    public class SampleService : ISampleService
    {
        private IDoStuff _businessLogic;

        public SampleService()
        {
            _businessLogic = new DoStuff();
        }

        public SampleService(IDoStuff business)
        {
            _businessLogic = business;
        }

        public DataResponse GetData(DataRequest request)
        {
            return _businessLogic.HandleRequest(request);
        }
    }
}

﻿using Company.WCF.Application.BusinessLogic;
using Company.WCF.Application.DataContracts;
using Company.WCF.Application.Service;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace $safeprojectname$
{
    [TestClass]
    public class ServiceTests
    {
        [TestMethod]
        [TestCategory("Unit tests")]
        public void ShouldBeAbleToCallAMockedService()
        {
            // Arrange
            Mock<IDoStuff> mockBL = new Mock<IDoStuff>();
            SampleService service = new SampleService(mockBL.Object);

            // 
            DataRequest request = new DataRequest() { Name = "mocked bl" };
            mockBL.Setup(x => x.HandleRequest(It.Is<DataRequest>(y => y.Name == "mocked bl")))
                  .Returns(new DataResponse() { Text = "Hello there" });

            // Act
            DataResponse response = service.GetData(request);

            // Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(response.Text, "Hello there");
        }

        [TestMethod]
        [TestCategory("Unit tests")]
        public void ShouldCheckBusinessLogic()
        {
            // Arrange
            IDoStuff businessLogic = new DoStuff();
            DataRequest request = new DataRequest() { Name = "Test Subject" };

            // Act
            DataResponse response = businessLogic.HandleRequest(request);

            // Assert
            Assert.IsNotNull(response);
            Assert.AreEqual(response.Text, "Hello Test Subject!");
        }
    }
}

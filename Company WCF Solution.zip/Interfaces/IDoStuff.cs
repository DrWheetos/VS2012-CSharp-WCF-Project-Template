﻿using Company.WCF.Application.DataContracts;

namespace Company.WCF.Application.BusinessLogic
{
    public interface IDoStuff
    {
        DataResponse HandleRequest(DataRequest request);
    }
}

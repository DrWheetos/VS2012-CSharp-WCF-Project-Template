﻿using Company.WCF.Application.Service;
using System;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace $safeprojectname$
{
    public class DebuggingHost
    {
        static void Main(string[] args)
        {
            // Fire up the WCF service.
            ServiceHost dataService = new ServiceHost(typeof(SampleService));
            dataService.Open();

            // Report back the endpoint URL that we can call the service on.
            foreach (ServiceEndpoint endpoint in dataService.Description.Endpoints)
            {
                Console.WriteLine("Listening on endpoint : " + endpoint.Address);
            }

            // Keep the console window open to keep the service running.
            Console.WriteLine("Service is running.  Press 'Enter' to exit...");
            Console.ReadLine();
        }
    }
}

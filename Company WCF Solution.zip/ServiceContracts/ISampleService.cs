﻿using Company.WCF.Application.DataContracts;
using System.ServiceModel;

namespace $safeprojectname$
{
    [ServiceContract]
    public interface ISampleService
    {
        [OperationContract]
        DataResponse GetData(DataRequest request);
    }
}

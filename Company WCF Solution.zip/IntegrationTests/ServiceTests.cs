﻿using Company.WCF.Application.DataContracts;
using Company.WCF.Application.Service;
using Company.WCF.Application.ServiceContracts;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace $safeprojectname$
{
    [TestClass]
    public class ServiceTests
    {
        [TestMethod]
        [TestCategory("Integration tests")]
        public void ShouldBeAbleToCallTheService()
        {
            // Arrange
            ISampleService service = new SampleService();
            DataRequest request = new DataRequest() { Name = "Simon" };

            // Act
            DataResponse response= service.GetData(request);

            // Assert
            Assert.AreEqual(response.Text, "Hello Simon!");
        }
    }
}

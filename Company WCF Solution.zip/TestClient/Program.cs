﻿using Company.WCF.Application.DataContracts;
using Company.WCF.Application.ServiceContracts;
using System;
using System.ServiceModel;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create a channel to the service
            ChannelFactory<ISampleService> serviceFactory = 
                new ChannelFactory<ISampleService>("OurServiceEndpoint");
            ISampleService serviceChannel = serviceFactory.CreateChannel();

            // Create an input request and call the service
            DataRequest request = new DataRequest() { Name = "Susan" };
            DataResponse response = serviceChannel.GetData(request);

            // Write confirmation of response to user
            Console.WriteLine("Service response is : {0}", response.Text);
            Console.WriteLine();
            Console.WriteLine("Press 'Enter' to quit...");
            Console.ReadLine();
        }
    }
}
